package edu.miracostacollege.todo2day;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import edu.miracostacollege.todo2day.Model.DBHelper;

public class MainActivity extends AppCompatActivity {

    private DBHelper mDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDb = new DBHelper(this);


    }

    //Ctrl + o => override methods
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDb.close();
    }
}
